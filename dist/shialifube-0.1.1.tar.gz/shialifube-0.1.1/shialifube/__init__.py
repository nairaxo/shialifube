# shialifube/__init__.py
from .transliterator import transliterate
